const mysql = require("mysql2/promise");
const config = require("../config");

let connection;
try {

    connection = mysql.createPool({
        host: config.db.host,
        user: config.db.user,
        password: config.db.password,
        database: config.db.database,
        waitForConnections: true,
        port: config.db.port,
        connectionLimit: 10,
        queueLimit: 0,
    })
    console.log("Connection pool created successfully.");
} catch (error) {
    console.error("Failed to create connection pool:", error.message);
    process.exit(1); // Exit the application if the pool cannot be created
}


const testConnection = async () => {
    try {
        const conn = await connection.getConnection(); // Get a connection from the pool
        console.log("Database connection successful!");
        conn.release(); // Release the connection back to the pool
    } catch (error) {
        console.error("Database connection failed:", error.message);
    }
};

testConnection();

module.exports = connection;
