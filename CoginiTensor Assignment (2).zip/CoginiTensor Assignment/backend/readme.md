git clone <repository_url>
cd cogitensor Assignment/backend

npm install
npm start
