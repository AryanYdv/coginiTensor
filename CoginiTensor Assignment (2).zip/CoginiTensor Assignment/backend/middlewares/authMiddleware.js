const jwt = require('jsonwebtoken');
const pool = require('../utils/db');
const config = require('../config');

const authMiddleware = async (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.split(' ')[1];
    try {
      const decoded = jwt.verify(token, config.jwtSecret);
      const [rows] = await pool.query('SELECT id, email FROM users WHERE id = ?', [decoded.id]);

      if (rows.length === 0) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      req.user = rows[0];
      next();
    } catch (err) {
      return res.status(401).json({ message: 'Invalid Token' });
    }
  } else {
    return res.status(401).json({ message: 'No Token Provided' });
  }
};
module.exports = authMiddleware;
