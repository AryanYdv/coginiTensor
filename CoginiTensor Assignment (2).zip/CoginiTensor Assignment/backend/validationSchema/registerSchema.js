const Joi = require("joi");

const registerSchema = Joi.object({
    email:Joi.string().required(),
    userPassword: Joi.string().min(4).required(),
  });

  module.exports={
    registerSchema
}