// routes/taskRoutes.js
const express = require("express");
const TaskController = require("../controllers/taskController");
const jwt = require("jsonwebtoken");
const { jwtSecret } = require("../config");
const authenticate=require("../middlewares/authMiddleware")

const router = express.Router();

// auth middleware
router.use(authenticate);

// Task routes
router.get("/api/getAllTask", TaskController.getTasks); // Get all tasks
router.post("/api/createNewTask", TaskController.createTask); // Add a new task
router.get("/api/getTaskById/:id", TaskController.getTaskById); // Get task details
router.put("/api/updateTaskById/:id", TaskController.updateTask); // Update a task
router.patch("/api/toggleStatusById/:id", TaskController.toggleTaskStatus); // Toggle task status
router.delete("/api/deleteTaskById/:id", TaskController.deleteTask); // Delete a task

module.exports = router;
