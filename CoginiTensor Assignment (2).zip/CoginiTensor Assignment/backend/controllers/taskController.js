// controllers/taskController.js

const  connection  = require("../utils/db");

exports.getTasks = async (req, res) => {
  try {
    const userId = req.user.id;
    // Filters
    const { taskStatus, due_date, search, page = 1, limit = 10 } = req.query;

    // Pagination
    const offset = (page - 1) * limit;

    let query = "SELECT * FROM tasks WHERE user_id = ?";
    const params = [userId];

    //filters
    if (taskStatus) {
      query += " AND taskStatus = ?";
      params.push(taskStatus);
    }
    if (due_date) {
      query += " AND due_date = ?";
      params.push(due_date);
    }

    //searching
    if (search) {
      query += " AND (title LIKE ? OR userDescription LIKE ?)";
      params.push(`%${search}%`, `%${search}%`);
    }

    //pagination
    query += " LIMIT ? OFFSET ?";
    params.push(parseInt(limit), parseInt(offset));

    // Execute Query
    const [tasks] = await connection.query(query, params);

    // Get Total Count (for pagination metadata)
    const [totalCountResult] = await connection.query(
      "SELECT COUNT(*) AS count FROM tasks WHERE user_id = ?",
      [userId]
    );
    const totalCount = totalCountResult[0].count;

    res.status(200).json({
      tasks,
      pagination: {
        currentPage: parseInt(page),
        totalPages: Math.ceil(totalCount / limit),
        totalTasks: totalCount,
      },
    });
  } catch (err) {
    res.status(500).json({ message: "Server error.", error: err.message });
  }
};

exports.createTask = async (req, res) => {
  try {
    const { title, userDescription, taskStatus, due_date } = req.body;
    const userId = req.user.id;
    await connection.query(
      "INSERT INTO tasks (user_id, title, userDescription, taskStatus, due_date) VALUES (?, ?, ?, ?, ?)",
      [userId, title, userDescription, taskStatus, due_date]
    );

    res.status(201).json({ message: "Task created successfully." });
  } catch (err) {
    res.status(500).json({ message: "Server error.", error: err.message });
  }
};

exports.getTaskById = async (req, res) => {
  try {
    const { id } = req.params;
    const [tasks] = await connection.query("SELECT * FROM tasks WHERE id = ?", [id]);

    if (tasks.length === 0) {
      return res.status(404).json({ message: "Task not found." });
    }

    res.status(200).json(tasks[0]);
  } catch (err) {
    res.status(500).json({ message: "Server error.", error: err.message });
  }
};

exports.updateTask = async (req, res) => {
  try {
    const { id } = req.params;
    const { title, userDescription, taskStatus, due_date } = req.body;

    const [result] = await connection.query(
      "UPDATE tasks SET title = ?, userDescription = ?, taskStatus = ?, due_date = ? WHERE id = ?",
      [title, userDescription, taskStatus, due_date, id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Task not found." });
    }

    res.status(200).json({ message: "Task updated successfully." });
  } catch (err) {
    res.status(500).json({ message: "Server error.", error: err.message });
  }
};

exports.deleteTask = async (req, res) => {
  try {
    const { id } = req.params;
    const [result] = await connection.query("DELETE FROM tasks WHERE id = ?", [id]);

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Task not found." });
    }

    res.status(200).json({ message: "Task deleted successfully." });
  } catch (err) {
    res.status(500).json({ message: "Server error.", error: err.message });
  }
};

exports.toggleTaskStatus = async (req, res) => {
  try {
    const { id } = req.params;

    const [tasks] = await connection.query("SELECT taskStatus FROM tasks WHERE id = ?", [id]);

    if (tasks.length === 0) {
      return res.status(404).json({ message: "Task not found." });
    }

    const currentStatus = tasks[0].taskStatus;
    const newStatus = currentStatus === "Pending" ? "Completed" : "Pending";

    await connection.query("UPDATE tasks SET taskStatus = ? WHERE id = ?", [newStatus, id]);
    res.status(200).json({ message: "Task status updated successfully." });
  } catch (err) {
    res.status(500).json({ message: "Server error.", error: err.message });
  }
};
