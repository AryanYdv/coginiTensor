const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const {loginSchema}=require("../validationSchema/loginSchema");
const {registerSchema}=require("../validationSchema/registerSchema");
const connection = require("../utils/db");
const config=require("../config");

const generateToken = (user) => {
  return jwt.sign({ id: user.id }, config.jwtSecret, {
    expiresIn: "1d",
  });
};

exports.register = async (req, res) => {
  try {
    const { error } = registerSchema.validate(req.body);
    if (error)
      return res.status(400).json({ message: error.details[0].message });

    const { email, userPassword } = req.body;

    const [existingUser] = await connection.query(
      "SELECT id FROM users WHERE email = ?",
      [email]
    );
    if (existingUser.length > 0)
      return res.status(400).json({ message: "Email already exists!" });

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(userPassword, salt);

    const [result] = await connection.query(
      "INSERT INTO users (email, userPassword) VALUES (?,?)",
      [email,hashedPassword]
    );
    const userId = result.insertId;

    const token = generateToken({ id: userId });
  
    res.status(201).json({ token });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server Error" });
  }
};

exports.login = async (req, res) => {
  try {
    const { error } = loginSchema.validate(req.body);
    if (error)
      return res.status(400).json({ message: error.details[0].message });

    const { email,userPassword } = req.body;

    const [users] = await connection.query("SELECT * FROM users WHERE email = ?", [
      email
    ]);
    if (users.length === 0)
      return res.status(400).json({ message: "Invalid credentials" });

    const user = users[0];
    const isValid = await bcrypt.compare(userPassword, user.userPassword);
    if (!isValid)
      return res.status(400).json({ message: "Invalid credentials" });

    const token = generateToken(user);
    res.status(200).json({ token });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server Error" });
  }
}